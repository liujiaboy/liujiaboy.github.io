//
//  AppDelegate.m
//  NoteIOS12
//
//  Created by HK on 2018/11/19.
//  Copyright © 2018年 HK. All rights reserved.
//

#import "AppDelegate.h"
#import <UserNotifications/UserNotifications.h>

@interface AppDelegate () <UNUserNotificationCenterDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [self requestAuthorization];
//    [self registerLocalNotification];
    
    return YES;
}

- (void)requestAuthorization {
    if (@available(iOS 10.0,*)) {
        UNAuthorizationOptions options = UNAuthorizationOptionAlert|UNAuthorizationOptionBadge|UNAuthorizationOptionSound;
        if (@available(iOS 12.0, *)) {
            options |= UNAuthorizationOptionProvisional;
        }
        UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
        center.delegate = self;
        [center requestAuthorizationWithOptions:options completionHandler:^(BOOL granted, NSError * _Nullable error) {
            if (granted) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[UIApplication sharedApplication] registerForRemoteNotifications];
                });
            }
        }];
    }
}

- (void)registerLocalNotification {
    if (@available(iOS 12.0,*)) {
        NSMutableSet *set = [[NSMutableSet alloc] init];
        NSString * summaryFormat = @"%u more message and %@";
        NSString * hiddenPreviewsBodyPlaceholder = @"%u个秘密哟";
        NSString *caterogyId0 = @"caterogyId0";
        UNNotificationCategory *category = [UNNotificationCategory categoryWithIdentifier:caterogyId0 actions:@[] intentIdentifiers:@[] hiddenPreviewsBodyPlaceholder:hiddenPreviewsBodyPlaceholder categorySummaryFormat:summaryFormat options:0];
        [set addObject:category];
        
        [UNUserNotificationCenter.currentNotificationCenter setNotificationCategories:set];

        for (int i = 0; i < 5; i++) {
            UNMutableNotificationContent *content = [[UNMutableNotificationContent alloc] init];
            content.title = [NSString stringWithFormat:@"title-%d",i];
            content.subtitle = [NSString stringWithFormat:@"subtitle-%d",i];
            content.body = @"呼哈哈哈哈哈";
            if (i>1) {
                content.threadIdentifier = @"thread-knowledge";
                
                content.categoryIdentifier = caterogyId0;
                content.summaryArgument = @"I'm killing you";
                content.summaryArgumentCount = 1;
            } else {
                content.threadIdentifier = @"thread-other";
            }
            NSTimeInterval interval = 5+i*3;
            UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:interval repeats:NO];
            UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:[NSString stringWithFormat:@"local-%d",i] content:content trigger:trigger];
            
            [UNUserNotificationCenter.currentNotificationCenter addNotificationRequest:request withCompletionHandler:nil];
        }
    }
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler  API_AVAILABLE(ios(10.0)){

    completionHandler();
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler  API_AVAILABLE(ios(10.0)){
    
    if (@available(iOS 10.0, *)) {
        completionHandler(UNAuthorizationOptionAlert|UNAuthorizationOptionBadge|UNAuthorizationOptionSound);
    } else {
        // Fallback on earlier versions
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
