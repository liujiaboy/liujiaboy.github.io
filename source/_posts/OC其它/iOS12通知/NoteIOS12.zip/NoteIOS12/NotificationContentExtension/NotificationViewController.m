//
//  NotificationViewController.m
//  NotificationContentExtension
//
//  Created by HK on 2018/11/27.
//  Copyright © 2018年 HK. All rights reserved.
//

#import "NotificationViewController.h"
#import <UserNotifications/UserNotifications.h>
#import <UserNotificationsUI/UserNotificationsUI.h>

@interface NotificationViewController () <UNNotificationContentExtension>

@property IBOutlet UILabel *label;
@property (strong, nonatomic) IBOutlet UIButton *button;

@end

@implementation NotificationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.button addTarget:self action:@selector(read:) forControlEvents:UIControlEventTouchUpInside];
    // Do any required interface initialization here.
}

- (void)didReceiveNotification:(UNNotification *)notification {
    self.label.text = notification.request.content.body;
}

- (void)read:(UIButton *)button {
    NSLog(@"--button tap--");
    [button setTitle:@"嘿" forState:UIControlStateNormal];
}

- (void)didReceiveNotificationResponse:(UNNotificationResponse *)response completionHandler:(void (^)(UNNotificationContentExtensionResponseOption))completion {
    NSLog(@"==%s==",__func__);
    completion(UNNotificationContentExtensionResponseOptionDismissAndForwardAction);
}

@end
